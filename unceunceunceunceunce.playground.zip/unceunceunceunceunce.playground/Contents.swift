import UIKit

var hw = "Hello, World!"
var success = "YEAAAAH THERE WE GO"
var unce = "unce unce unce unce unce"
